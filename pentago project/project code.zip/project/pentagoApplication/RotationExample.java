package pentagoApplication;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class RotationExample extends JFrame {

	public RotationExample() {
		setTitle("회전함수");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(600, 600);
		setVisible(true);
		Container con = getContentPane();
		JPanel pan = new JPanel();
		pan.setBackground(Color.BLACK);
		pan.setSize(50, 50);
		pan.setLocation(50,50);
		Runnable th = rotation(25, 25, 10d, pan);
		Thread r_th = new Thread(th);
		con.setLayout(null);
		con.add(pan);
		r_th.start();
	};

	public static Runnable rotation(int x, int y, double v, JComponent E) {
		Runnable th = () -> {
			Double t = 0d;
			while (true) {

				E.setLocation(
						(int) (x + (Math.cos(v * t))
								* (Math.sqrt(Math.pow((x - E.getX()), 2) + Math.pow((y - E.getY()), 2)))),
						(int) (y + (-Math.sin(v * t))
								* (Math.sqrt(Math.pow((x - E.getX()), 2) + Math.pow((y - E.getY()), 2)))));
				t += 0.0166666666666666667;
				if (E.getY() - y == 5) {
					break;
				}
				try {
					Thread.sleep(1000 / 60);
				} catch (InterruptedException e) {
					e.getMessage();
				}
			}

		};
		return th;
	}

	public static void main(String args[]) {
		RotationExample asdf = new RotationExample();
	}
}
