package pentagoApplication;

import java.util.ArrayList;

public class AI {
	private Board maxBoard;
	private int max = 0;
	private int depth = 0;
	
	public AI(int d) {
		
		depth = d;
		max = 0;
	}
	
	public Board getBoard()
	{
		return maxBoard;
	}

	public int intelligentMove(int depth, GameTree currentTree, boolean maximizingPlayer) 
	{
		int bestVal = 0;
		
		//트리의 루트 노드
		if(depth == 0)
		{
			return currentTree.getBoard().getUtility();
		}
		
		if(maximizingPlayer) //최대 선택
		{
			bestVal = Integer.MIN_VALUE;
			currentTree.populateNodeChildren();
			ArrayList<GameTree> childTrees = currentTree.getChildTrees();
			
			//현 트리노드의 각각의 자식트리
			for(int i = 0; i < childTrees.size(); i++)
			{
				//get max utility value
				int thisVal = intelligentMove(depth - 1, childTrees.get(i), false);
				if(bestVal < thisVal)
					bestVal = thisVal;
			}
			
			//부모보다 한 단계 낮은 depth 가 재귀문을 통해 도달하고 보드가 이전상태보다 결과값이 좋으면 다음의 새 보드로 교체
			if(bestVal > max && depth == this.depth - 1)
			{
				max = bestVal;
				maxBoard = currentTree.getBoard();
			}
			return bestVal;
		}
		else  //minimizing player 최소선택
		{
			bestVal = Integer.MAX_VALUE;
			currentTree.populateNodeChildren();
			ArrayList<GameTree> childTrees = currentTree.getChildTrees();
			for(int i = 0; i < childTrees.size(); i++)
			{
				int thisVal = intelligentMove(depth - 1, childTrees.get(i), true);
				if(bestVal > thisVal)
					bestVal = thisVal;
				
			}
			return bestVal;
		}
	}
	
	
}
