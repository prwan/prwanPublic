package pentagoApplication;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.LineBorder;

//구성 : ExitButton, 메뉴바, 배경화면 출력, 배경음악 (Ctrl + F)
public class Pentago extends JFrame {
	public static boolean soundStatus = true;
	public static boolean timeLimit = true;
	public final static int depth = 2; // AI

	private Image ResultImage;
	private Image screenImage;
	private Graphics screenGraphic;

	private Image ResultPanelimg = new ImageIcon(Main.class.getResource("../images/ResultPanel.png")).getImage();
	private Image introBackground = new ImageIcon(Main.class.getResource("../images/PentagoBackGround.jpg")).getImage();
	private JLabel menuBar = new JLabel(new ImageIcon(Main.class.getResource("../images/menubar.png")));

	private ImageIcon backButtonON = new ImageIcon(Main.class.getResource("../images/backButtonOn.png"));
	private ImageIcon backButtonOFF = new ImageIcon(Main.class.getResource("../images/backButtonOff.png"));
	private ImageIcon exitButtonON = new ImageIcon(Main.class.getResource("../images/xbuttonon.png"));
	private ImageIcon exitButtonOFF = new ImageIcon(Main.class.getResource("../images/xbutton.png"));
	private ImageIcon ExButtonOn = new ImageIcon(Main.class.getResource("../images/ExButtonOn.png"));
	private ImageIcon ExButtonOff = new ImageIcon(Main.class.getResource("../images/ExButtonOff.png"));
	private ImageIcon StartComputerButtonOn = new ImageIcon(
			Main.class.getResource("../images/StartComputerButtonOn.png"));
	private ImageIcon StartComputerButtonOff = new ImageIcon(
			Main.class.getResource("../images/StartComputerButtonOff.png"));
	private ImageIcon StartFriendButtonOn = new ImageIcon(Main.class.getResource("../images/StartFriendButtonOn.png"));
	private ImageIcon StartFriendButtonOff = new ImageIcon(
			Main.class.getResource("../images/StartFriendButtonOff.png"));
	private ImageIcon MainButtonOn = new ImageIcon(Main.class.getResource("../images/MainButtonOn.png"));
	private ImageIcon MainButtonOff = new ImageIcon(Main.class.getResource("../images/MainButtonOff.png"));
	private ImageIcon RestartbuttonOff = new ImageIcon(Main.class.getResource("../images/RestartButtonOff.png"));
	private ImageIcon RestartbuttonOn = new ImageIcon(Main.class.getResource("../images/RestartButtonOn.png"));
	private ImageIcon ExImage1 = new ImageIcon(Main.class.getResource("../images/Eximg1.png"));
	private ImageIcon ExImage2 = new ImageIcon(Main.class.getResource("../images/Eximg2.png"));
	private ImageIcon ExImage3 = new ImageIcon(Main.class.getResource("../images/Eximg3.png"));
	private ImageIcon SoundOn = new ImageIcon(Main.class.getResource("../images/soundOn.png"));
	private ImageIcon SoundOff = new ImageIcon(Main.class.getResource("../images/soundOff.png"));
	public static Music introMusic = new Music("아기펭귄 ( Cute Piano Music - Baby Penguin ).mp3", true);

	private JPanel ExPanel = new JPanel();
	private JPanel panel1 = new JPanel();
	private JPanel panel2 = new JPanel();

	// -------------------------------------------------------------------------------------------------

	static ImageIcon rotation[] = new ImageIcon[8];
	private static JButton[] rotationButton = new JButton[8];

	// -------------------------------------------------------------------------------------------------
	private JButton backButton = new JButton(backButtonOFF);
	private JButton exitButton = new JButton(exitButtonOFF);
	private JButton GameStartButtonDouble = new JButton(StartFriendButtonOff);
	private JButton GameStartButtonSingle = new JButton(StartComputerButtonOff);
	private JButton ExButton = new JButton(ExButtonOff);
	private JButton Restartbutton = new JButton(RestartbuttonOff);
	private JButton MainButton = new JButton(MainButtonOff);
	static JLabel ResultLabel = new JLabel();
	private static JLabel WLabel = new JLabel(new ImageIcon(Main.class.getResource("../images/WhiteStoneTurn.png")));
	private static JLabel BLabel = new JLabel(new ImageIcon(Main.class.getResource("../images/BlackStoneTurn.png")));
	public static CountdownTimer cdtblack;
	public static CountdownTimer cdtwhite;
	public static ResultTimer cdtR;
	private JButton MusicButton = new JButton(SoundOn);

	// -------------------------------------------------------------------------------------------------

	public static void TurnSet() {
		if (!BasicPanel.AiFlag) {
			if (BasicPanel.playerTurn) {

				cdtwhite.seconds = 31;
				cdtblack.seconds = 31;
				WLabel.setVisible(true);
				BLabel.setVisible(false);
				cdtblack.setVisible(false);
				cdtwhite.setVisible(true);

			} else {
				cdtwhite.seconds = 31;
				cdtblack.seconds = 31;
				WLabel.setVisible(false);
				BLabel.setVisible(true);
				cdtblack.setVisible(true);
				cdtwhite.setVisible(false);
			}
		}
	}

	public static void RotationButtonOn() {
		for (int a = 0; a < 8; a++) {
			rotationButton[a].setVisible(true);
		}
	}

	public static void RotationButtonOff() {
		for (int a = 0; a < 8; a++) {
			rotationButton[a].setVisible(false);
		}
	}

	private int mouseX, mouseY;
	private JPanel Game;
	private JPanel Base = new JPanel();
	static JPanel ResultPanel;

	public void resetBase() {
		// --------------------Base패널 설정---------------------
		Base.removeAll();
		Base.setVisible(false);
		Base.setSize(1280, 780);
		Base.setLocation(0, 30);
		Base.setLayout(null);
		Base.setBackground(new Color(0, 0, 0, 0));
		Base.add(backButton);
		// -------------------Base패널에 패널 넣기------------------
		BasicPanel screenPanel = new BasicPanel();
		screenPanel.setLocation(350, 80);
		screenPanel.setSize(600, 600);
		screenPanel.setLayout(new GridLayout(6, 6, 5, 0));
		screenPanel.setBackground(Color.white);
		Base.add(screenPanel);

	}

	public Pentago() {

		rotation[0] = new ImageIcon(Main.class.getResource("../Rimages/rotation1.png"));
		rotation[1] = new ImageIcon(Main.class.getResource("../Rimages/rotation2.png"));
		rotation[2] = new ImageIcon(Main.class.getResource("../Rimages/rotation3.png"));
		rotation[3] = new ImageIcon(Main.class.getResource("../Rimages/rotation4.png"));
		rotation[4] = new ImageIcon(Main.class.getResource("../Rimages/rotation5.png"));
		rotation[5] = new ImageIcon(Main.class.getResource("../Rimages/rotation6.png"));
		rotation[6] = new ImageIcon(Main.class.getResource("../Rimages/rotation7.png"));
		rotation[7] = new ImageIcon(Main.class.getResource("../Rimages/rotation8.png"));
		Game = new JPanel();
		setContentPane(Game);
		Game.setSize(Main.SCREEN_WIDTH, Main.SCREEN_HEIGHT);
		setUndecorated(true); // 기본적으로 존재하는 메뉴바 안보이게 함.
		setTitle("pentago");
		setSize(Main.SCREEN_WIDTH, Main.SCREEN_HEIGHT);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBackground(new Color(0, 0, 0, 0)); // 배경 하얀색으로 바꿈
		setLayout(null);
		Game.add(Base);

		// --------------------배경음악--------------------
		introMusic.start();

		// --------------------플레이어 타이머 표시---------------
		cdtblack = new CountdownTimer();
		cdtwhite = new CountdownTimer();
		cdtblack.setVisible(false);
		cdtwhite.setVisible(false);
		Game.add(cdtwhite);
		cdtwhite.setSize(300, 25);
		cdtwhite.setLocation(94, 450);
		Game.add(cdtblack);
		cdtblack.setSize(300, 25);
		cdtblack.setLocation(1074, 450);

		cdtR = new ResultTimer();
		cdtR.setVisible(false);
		cdtR.setSize(300, 25);
		cdtR.setLocation(536, 50);
		Game.add(cdtR);

		// --------------------플레이어 턴 표시---------------
		WLabel.setSize(100, 100);
		WLabel.setLocation(100, 360);
		WLabel.setVisible(false);
		Game.add(WLabel);

		BLabel.setSize(100, 100);
		BLabel.setLocation(1080, 360);
		BLabel.setVisible(false);
		Game.add(BLabel);

		// --------------------결과 패널-------------------

		ResultPanel = new JPanel() {
			public void paint(Graphics g) {
				ResultImage = createImage(ResultPanel.getWidth(), ResultPanel.getHeight());
				screenGraphic = ResultImage.getGraphics();
				screenDraw(screenGraphic);
				g.drawImage(ResultImage, 0, 0, null);
			}

			public void screenDraw(Graphics g) {
				g.drawImage(ResultPanelimg, 0, 0, null);
				paintComponents(g); // JLabel 그리기위함 , 고정된 이미지(버튼, 메뉴바 등)
				this.repaint();
			}
		};

		ResultPanel.setVisible(false);
		ResultPanel.setSize(500, 300);
		ResultPanel.setLocation(400, 270);
		ResultPanel.setLayout(null);

		ResultPanel.setBackground(Color.white);
		Game.add(ResultPanel);

		Restartbutton.setBounds(30, 200, 208, 40);
		Restartbutton.setBorderPainted(false);
		Restartbutton.setContentAreaFilled(false);
		Restartbutton.setFocusPainted(false);
		Restartbutton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				Restartbutton.setIcon(RestartbuttonOn);
				Restartbutton.setCursor(new Cursor(Cursor.HAND_CURSOR));
//				Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
//				buttonEnteredMusic.start();
			}

			@Override
			public void mouseExited(MouseEvent e) {
				Restartbutton.setIcon(RestartbuttonOff);
				Restartbutton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}

			@Override
			public void mousePressed(MouseEvent e) {
//				Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
//				buttonEnteredMusic.start();
//				introMusic.close(); // 게임스타트 버튼 누르면 노래 정지시킴
				BasicPanel.b.removeAll();
				gameStart();
				TurnSet();
				ResultPanel.setVisible(false);
			}
		});

		MainButton.setVisible(true);
		MainButton.setBounds(320, 200, 131, 40);// JButton 모양 기본적으로 있음 -> 커스텀 해주어야 함
		MainButton.setBorderPainted(false);
		MainButton.setContentAreaFilled(false);
		MainButton.setFocusPainted(false);
		MainButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				MainButton.setIcon(MainButtonOn);
				MainButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
//				Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
//				buttonEnteredMusic.start();
			}

			@Override
			public void mouseExited(MouseEvent e) {
				MainButton.setIcon(MainButtonOff);
				MainButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}

			@Override
			public void mousePressed(MouseEvent e) {
//				Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
//				buttonEnteredMusic.start();
				BasicPanel.b.removeAll();
				GameStartButtonDouble.setVisible(true);
				GameStartButtonSingle.setVisible(true);
				introBackground = new ImageIcon(Main.class.getResource("../images/PentagoBackGround.jpg")).getImage();
				backButton.setVisible(false);
				RotationButtonOff();
				WLabel.setVisible(false);
				BLabel.setVisible(false);
				cdtblack.setVisible(false);
				cdtwhite.setVisible(false);
				Base.setVisible(false);
				ResultPanel.setVisible(false);
				ExButton.setVisible(true);
//				introMusic = new Music("아기펭귄 ( Cute Piano Music - Baby Penguin ).mp3", false);
//				introMusic.start(); // 게임스타트 버튼 누르면 노래 정지시킴
				cdtR.setVisible(false);
			}
		});

		ResultLabel.setBounds(50, 50, 400, 100);// JButton 모양 기본적으로 있음 -> 커스텀 해주어야 함
		ResultLabel = new JLabel();
		ResultLabel.setFont(ResultLabel.getFont().deriveFont(20.0f));
		ResultPanel.add(ResultLabel);
		ResultPanel.add(Restartbutton);
		ResultPanel.add(MainButton);

		// -------------------음악버튼--------------------
		MusicButton.setBounds(20, 680, 73, 73);
		MusicButton.setBorderPainted(false);
		MusicButton.setContentAreaFilled(false);
		MusicButton.setFocusPainted(false);
		MusicButton.setBackground(Color.orange);
		MusicButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				MusicButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
//				Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
//				buttonEnteredMusic.start();
			}

			@Override
			public void mouseExited(MouseEvent e) {
				MusicButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}

			@Override
			public void mousePressed(MouseEvent e) {
				MusicButton.setIcon(SoundOff);
				if (soundStatus == true) {
					introMusic.suspend();
					soundStatus = false;
					if (soundStatus == true)
						MusicButton.setIcon(SoundOn);
					if (soundStatus == false)
						MusicButton.setIcon(SoundOff);
					introMusic.suspend();

				} else if (soundStatus == false) {
					soundStatus = true;
					if (soundStatus == true)
						MusicButton.setIcon(SoundOn);
					if (soundStatus == false)
						MusicButton.setIcon(SoundOff);

					introMusic.resume(); // 게임스타트 버튼 누르면 노래 정지시킴

				}
			}
		});

		Game.add(MusicButton);

		// -------------------게임설명--------------------

		ExPanel.setVisible(false);
		ExPanel.setSize(860, 500);
		ExPanel.setLocation(210, 150);
		ExPanel.setBackground(Color.white);
		ExPanel.setBorder(new LineBorder(Color.lightGray, 3));
		ExPanel.setLayout(new BorderLayout());

		panel1.setLayout(null);
		panel1.setBackground(Color.WHITE);
		panel2.setBackground(Color.LIGHT_GRAY);

		JLabel Title = new JLabel("게임설명");
		Title.setFont(new Font("", Font.BOLD, 35));
		Title.setBackground(Color.LIGHT_GRAY);
		Title.setForeground(Color.white);
		Title.setOpaque(true);
		Title.setHorizontalAlignment(SwingConstants.CENTER);

		JTextArea Text = new JTextArea(51, 25);
		Text.setFont(new Font("", Font.PLAIN, 20));
		Text.setText("\n\n\n 1. 게임이 시작되면 전체 판의 한 곳을 \n     클릭해 돌을 놓습니다.\n\n\n\n\n\n\n\n\n\n\n\n"
				+ " 2. 4개의 판 중 하나의 판을 선택해 원하는\n     방향으로 90도 돌립니다.\n   "
				+ "  이 때 돌을 놓지 않은 판을 대신 \n     돌려도 됩니다.\n\n\n\n\n\n\n\n\n\n\n\n\n"
				+ " 3. 돌을 놓거나 판을 돌린 후 가로나 세로, \n     대각선으로 돌 5개가 이어지면 \n     승리 합니다.");
		Text.setEditable(false);
		JLabel Image1 = new JLabel(ExImage1);
		Image1.setBounds(10, 0, 400, 400);

		JLabel Image2 = new JLabel(ExImage2);
		Image2.setBounds(5, 380, 400, 400);

		JLabel Image3 = new JLabel(ExImage3);
		Image3.setBounds(10, 750, 400, 400);

		JSplitPane Split = new JSplitPane();
		Split.setLeftComponent(Text);
		Split.setRightComponent(panel1);
		Split.setDividerLocation(416);
		Split.setEnabled(false);
		Split.setDividerSize(4);

		JScrollPane Scroll = new JScrollPane(Split);
		Scroll.setBorder(new LineBorder(Color.LIGHT_GRAY));
		Scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		Scroll.getVerticalScrollBar().setUnitIncrement(20);

		JButton Out = new JButton("나가기");
		Out.setFont(new Font("", Font.BOLD, 25));
		Out.setForeground(Color.white);
		Out.setBorderPainted(false);
		Out.setFocusPainted(false);
		Out.setBackground(Color.LIGHT_GRAY);
		Out.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
//				Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
//				buttonEnteredMusic.start();
				Out.setForeground(Color.black);
				Out.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}

			@Override
			public void mouseExited(MouseEvent e) {
				Out.setForeground(Color.white);
				Out.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}

			@Override
			public void mousePressed(MouseEvent e) {
//				Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
//				buttonEnteredMusic.start();

				Scroll.getVerticalScrollBar().setValue(0);
				ExPanel.setVisible(false);
				GameStartButtonDouble.setVisible(true);
				GameStartButtonSingle.setVisible(true);
				ExButton.setVisible(true);
			}
		});

		panel1.add(Image1);
		panel1.add(Image2);
		panel1.add(Image3);
		panel2.add(Out);
		ExPanel.add(Title, BorderLayout.NORTH);
		ExPanel.add(Scroll);
		ExPanel.add(panel2, BorderLayout.SOUTH);
		Game.add(ExPanel);

		// --------------------GameStartButton---------------
		GameStartButtonSingle.setBounds(850, 300, 385, 101);
		GameStartButtonSingle.setBorderPainted(false);
		GameStartButtonSingle.setContentAreaFilled(false);
		GameStartButtonSingle.setFocusPainted(false);
		GameStartButtonSingle.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				GameStartButtonSingle.setIcon(StartComputerButtonOn);
				GameStartButtonSingle.setCursor(new Cursor(Cursor.HAND_CURSOR));
//				Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
//				buttonEnteredMusic.start();
			}

			@Override
			public void mouseExited(MouseEvent e) {
				GameStartButtonSingle.setIcon(StartComputerButtonOff);
				GameStartButtonSingle.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}

			@Override
			public void mousePressed(MouseEvent e) {
//				Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
//				buttonEnteredMusic.start();
//				introMusic.close(); // 게임스타트 버튼 누르면 노래 정지시킴
				BasicPanel.AiFlag = true;
				gameStart();

			}
		});

		GameStartButtonDouble.setBounds(850, 450, 385, 101);
		GameStartButtonDouble.setBorderPainted(false);
		GameStartButtonDouble.setContentAreaFilled(false);
		GameStartButtonDouble.setFocusPainted(false);
		GameStartButtonDouble.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				GameStartButtonDouble.setIcon(StartFriendButtonOn);
				GameStartButtonDouble.setCursor(new Cursor(Cursor.HAND_CURSOR));
//				Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
//				buttonEnteredMusic.start();
			}

			@Override
			public void mouseExited(MouseEvent e) {
				GameStartButtonDouble.setIcon(StartFriendButtonOff);
				GameStartButtonDouble.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}

			@Override
			public void mousePressed(MouseEvent e) {
//				Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
//				buttonEnteredMusic.start();
//				introMusic.close(); // 게임스타트 버튼 누르면 노래 정지시킴
				BasicPanel.AiFlag = false;
				gameStart();
				TurnSet();
			}
		});

		Game.add(GameStartButtonSingle);
		Game.add(GameStartButtonDouble);

		// --------------------ExButton----------------------

		ExButton.setBounds(850, 600, 385, 101);
		ExButton.setBorderPainted(false);
		ExButton.setContentAreaFilled(false);
		ExButton.setFocusPainted(false);
		ExButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				ExButton.setIcon(ExButtonOn);
				ExButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
//				Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
//				buttonEnteredMusic.start();
			}

			@Override
			public void mouseExited(MouseEvent e) {
				ExButton.setIcon(ExButtonOff);
				ExButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}

			@Override
			public void mousePressed(MouseEvent e) {
				ExPanel.setVisible(true);
				GameStartButtonDouble.setVisible(false);
				GameStartButtonSingle.setVisible(false);
				ExButton.setVisible(false);

			}
		});

		Game.add(ExButton);

		// --------------------Backbutton--------------------
		backButton.setVisible(false);
		backButton.setBounds(20, 20, 50, 50);// JButton 모양 기본적으로 있음 -> 커스텀 해주어야 함
		backButton.setBorderPainted(false);
		backButton.setContentAreaFilled(false);
		backButton.setFocusPainted(false);
		backButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				backButton.setIcon(backButtonON);
				backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
//				Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
//				buttonEnteredMusic.start();
			}

			@Override
			public void mouseExited(MouseEvent e) {
				backButton.setIcon(backButtonOFF);
				backButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}

			@Override
			public void mousePressed(MouseEvent e) {
//				Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
//				buttonEnteredMusic.start();
				BasicPanel.b.removeAll();
				GameStartButtonDouble.setVisible(true);
				GameStartButtonSingle.setVisible(true);
				introBackground = new ImageIcon(Main.class.getResource("../images/PentagoBackGround.jpg")).getImage();
				backButton.setVisible(false);
				RotationButtonOff();
				WLabel.setVisible(false);
				BLabel.setVisible(false);
				cdtblack.setVisible(false);
				cdtwhite.setVisible(false);
				Base.setVisible(false);
				ExButton.setVisible(true);
				ResultPanel.setVisible(false);
				cdtR.setVisible(false);
				cdtR.second = 0;
//			    introMusic = new Music("아기펭귄 ( Cute Piano Music - Baby Penguin ).mp3", false);
//				introMusic.start(); // 게임스타트 버튼 누르면 노래 정지시킴
			}
		});

		// --------------------Exitbutton--------------------
		exitButton.setBounds(1245, 0, 30, 30);// JButton 모양 기본적으로 있음 -> 커스텀 해주어야 함
		exitButton.setBorderPainted(false);
		exitButton.setContentAreaFilled(false);
		exitButton.setFocusPainted(false);
		exitButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				exitButton.setIcon(exitButtonON);
				exitButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
//				Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
//				buttonEnteredMusic.start();
			}

			@Override
			public void mouseExited(MouseEvent e) {
				exitButton.setIcon(exitButtonOFF);
				exitButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}

			@Override
			public void mousePressed(MouseEvent e) {
				System.exit(0);
			}
		});
		Game.add(exitButton);

		// --------------------회전버튼--------------------

		for (int i = 0; i < 8; i++) {
			rotationButton[i] = new JButton(rotation[i]);

			rotationButton[i].setVisible(false);
			rotationButton[i].setBorderPainted(false);
			rotationButton[i].setContentAreaFilled(false);
			rotationButton[i].setFocusPainted(false);
			Game.add(rotationButton[i]);
		}

		rotationButton[0].setBounds(350, 60, 50, 50);// JButton 모양 기본적으로 있음 -> 커스텀 해주어야 함
		rotationButton[1].setBounds(300, 110, 50, 50);
		rotationButton[2].setBounds(900, 60, 50, 50);
		rotationButton[3].setBounds(950, 110, 50, 50);
		rotationButton[4].setBounds(350, 710, 50, 50);
		rotationButton[5].setBounds(300, 660, 50, 50);
		rotationButton[6].setBounds(900, 710, 50, 50);
		rotationButton[7].setBounds(950, 660, 50, 50);

		rotationButton[0].addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				panelRotate(0);
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}
		});

		rotationButton[1].addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				panelRotate(1);
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}
		});

		rotationButton[2].addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				panelRotate(2);
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}
		});

		rotationButton[3].addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				panelRotate(3);
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}
		});

		rotationButton[4].addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				panelRotate(4);
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}
		});

		rotationButton[5].addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				panelRotate(5);
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}
		});

		rotationButton[6].addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				panelRotate(6);
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}
		});

		rotationButton[7].addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				panelRotate(7);
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}
		});

		// --------------------메뉴바--------------------
		menuBar.setBounds(0, 0, 1280, 30);
		// 마우스 x,y 좌표 알아냄
		menuBar.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				mouseX = e.getX();
				mouseY = e.getY();
			}
		});
		menuBar.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				int x = e.getXOnScreen();
				int y = e.getYOnScreen();
				setLocation(x - mouseX, y - mouseY); // 메뉴바 드래그시 이벤트 처리
			}
		});
		Game.add(menuBar);

	}

	// --------------------배경화면 출력--------------------
	public void paint(Graphics g) {
		screenImage = createImage(Main.SCREEN_WIDTH, Main.SCREEN_HEIGHT);
		screenGraphic = screenImage.getGraphics();
		screenDraw(screenGraphic);
		g.drawImage(screenImage, 0, 0, null);
	}

	public void screenDraw(Graphics g) {
		g.drawImage(introBackground, 0, 0, null);
		paintComponents(g); // JLabel 그리기위함 , 고정된 이미지(버튼, 메뉴바 등)
		this.repaint();
	}

	// -------------------게임시작------------------------
	public void gameStart() {
		BasicPanel.playerTurn = false;
		introBackground = new ImageIcon(Main.class.getResource("../images/main.png")).getImage();
		backButton.setVisible(true);
		GameStartButtonDouble.setVisible(false);
		GameStartButtonSingle.setVisible(false);
		RotationButtonOff();
		resetBase();
		cdtR.setVisible(true);
		cdtR.min = 0;
		cdtR.second = 0;
		Base.setVisible(true);
		ExButton.setVisible(false);
		BasicPanel.FinalFlag = true;
		Game.add(Base);
		BasicPanel.flag = true;
		BasicPanel.winner = 0;
	}

	public void panelRotate(int Rnum) {

		Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
		buttonEnteredMusic.start();
		if (Rnum == 0) {
			// 0번 rotate
			if (BasicPanel.flag == false) {
				// --------오른쪽회전
				Board a = BasicPanel.b;
				Board c = new Board();
				for (int i = 0; i < 6; i++) {
					for (int j = 0; j < 6; j++) {
						c.board[i][j] = a.board[i][j];
					}
				}
				for (int i = 0; i < 3; i++) {
					for (int j = 0; j <= 2; j++) {
						c.board[i][j] = a.board[2 - j][i];
					}
				}
				BasicPanel.b = c;
				System.out.println("\n");
				System.out.print("<회전 후>");
				BasicPanel.b.Print();
				// 승리검사
				BasicPanel.winnerCheck();
				Board R = BasicPanel.b;

				for (int i = 0; i < 3; i++) {
					for (int j = 0; j < 3; j++) {
						BasicPanel.StonePanel[i][j].removeAll();
					}
				}

				// -----------
				for (int i = 0; i < 3; i++) {
					for (int j = 0; j < 3; j++) {
						if (R.board[i][j] == 0) {
							JLabel StoneFrame = new JLabel(
									new ImageIcon(Main.class.getResource("../images/StoneFrame.png")));
							BasicPanel.StonePanel[i][j].add(StoneFrame);
						} else if (R.board[i][j] == 1) {
							JLabel BlackStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/BlackStone.png")));
							BasicPanel.StonePanel[i][j].add(BlackStone);
						} else if (R.board[i][j] == 2) {
							JLabel WhiteStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/WhiteStone.png")));
							BasicPanel.StonePanel[i][j].add(WhiteStone);
						}
					}
				}

				// -----------
			}
			TurnSet();
			RotationButtonOff();
			BasicPanel.flag = true;
		}

		if (Rnum == 1) {
			// 1번 rotate
			if (BasicPanel.flag == false) {
				// --------왼쪽회전
				Board a = BasicPanel.b;
				Board c = new Board();
				for (int i = 0; i < 6; i++) {
					for (int j = 0; j < 6; j++) {
						c.board[i][j] = a.board[i][j];
					}
				}

				for (int i = 0; i < 3; i++) {
					for (int j = 0; j < 3; j++) {
						c.board[i][j] = a.board[j][2 - i];
					}
				}
				BasicPanel.b = c;
				System.out.println("\n");
				System.out.print("<회전 후>");
				BasicPanel.b.Print();
				// 승리검사
				BasicPanel.winnerCheck();

				Board R = BasicPanel.b;
				for (int i = 0; i < 3; i++) {
					for (int j = 0; j < 3; j++) {
						BasicPanel.StonePanel[i][j].removeAll();
					}
				}
				// -------
				for (int i = 0; i < 3; i++) {
					for (int j = 0; j < 3; j++) {
						if (R.board[i][j] == 0) {
							JLabel StoneFrame = new JLabel(
									new ImageIcon(Main.class.getResource("../images/StoneFrame.png")));
							BasicPanel.StonePanel[i][j].add(StoneFrame);

						} else if (R.board[i][j] == 1) {
							JLabel BlackStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/BlackStone.png")));
							BasicPanel.StonePanel[i][j].add(BlackStone);

						} else if (R.board[i][j] == 2) {
							JLabel WhiteStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/WhiteStone.png")));
							BasicPanel.StonePanel[i][j].add(WhiteStone);
						}
					}
				}
			}
			TurnSet();
			RotationButtonOff();
			BasicPanel.flag = true;
		}

		if (Rnum == 2) {
			// 2번 rotate
			if (BasicPanel.flag == false) {
				// --------왼쪽회전
				Board a = BasicPanel.b;
				Board c = new Board();
				for (int i = 0; i < 6; i++) {
					for (int j = 0; j < 6; j++) {
						c.board[i][j] = a.board[i][j];
					}
				}
				for (int i = 0; i < 3; i++) {
					for (int j = 3; j < 6; j++) {
						c.board[i][j] = a.board[j - 3][2 - i + 3];
					}
				}
				BasicPanel.b = c;
				System.out.println("\n");
				System.out.print("<회전 후>");
				BasicPanel.b.Print();
				// 승리검사
				BasicPanel.winnerCheck();
				Board R = BasicPanel.b;
				for (int i = 0; i < 3; i++) {
					for (int j = 3; j < 6; j++) {
						BasicPanel.StonePanel[i][j].removeAll();
					}
				}
				// ------
				for (int i = 0; i < 3; i++) {
					for (int j = 3; j < 6; j++) {
						if (R.board[i][j] == 0) {
							JLabel StoneFrame = new JLabel(
									new ImageIcon(Main.class.getResource("../images/StoneFrame.png")));
							BasicPanel.StonePanel[i][j].add(StoneFrame);

						} else if (R.board[i][j] == 1) {
							JLabel BlackStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/BlackStone.png")));
							BasicPanel.StonePanel[i][j].add(BlackStone);

						} else if (R.board[i][j] == 2) {
							JLabel WhiteStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/WhiteStone.png")));
							BasicPanel.StonePanel[i][j].add(WhiteStone);

						}
					}
				}
				// ------
			}
			TurnSet();
			RotationButtonOff();
			BasicPanel.flag = true;
		}

		if (Rnum == 3) {
			// 3번 rotate
			if (BasicPanel.flag == false) {
				// --------오른쪽회전
				Board a = BasicPanel.b;
				Board c = new Board();
				for (int i = 0; i < 6; i++) {
					for (int j = 0; j < 6; j++) {
						c.board[i][j] = a.board[i][j];
					}
				}
				for (int i = 0; i < 3; i++) {
					for (int j = 3; j < 6; j++) {
						c.board[i][j] = a.board[5 - j][i + 3];
					}
				}
				BasicPanel.b = c;
				System.out.println("\n");
				System.out.print("<회전 후>");
				BasicPanel.b.Print();
				// 승리검사
				BasicPanel.winnerCheck();
				Board R = BasicPanel.b;
				for (int i = 0; i < 3; i++) {
					for (int j = 3; j < 6; j++) {
						BasicPanel.StonePanel[i][j].removeAll();
					}
				}
				// ------
				for (int i = 0; i < 3; i++) {
					for (int j = 3; j < 6; j++) {
						if (R.board[i][j] == 0) {
							JLabel StoneFrame = new JLabel(
									new ImageIcon(Main.class.getResource("../images/StoneFrame.png")));
							BasicPanel.StonePanel[i][j].add(StoneFrame);

						} else if (R.board[i][j] == 1) {
							JLabel BlackStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/BlackStone.png")));
							BasicPanel.StonePanel[i][j].add(BlackStone);

						} else if (R.board[i][j] == 2) {
							JLabel WhiteStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/WhiteStone.png")));
							BasicPanel.StonePanel[i][j].add(WhiteStone);

						}
					}
				}
				// ------
			}
			TurnSet();
			RotationButtonOff();
			BasicPanel.flag = true;
		}

		if (Rnum == 4) {
			// 4번 rotate
			if (BasicPanel.flag == false) {
				// --------왼쪽회전
				Board a = BasicPanel.b;
				Board c = new Board();
				for (int i = 0; i < 6; i++) {
					for (int j = 0; j < 6; j++) {
						c.board[i][j] = a.board[i][j];
					}
				}
				for (int i = 3; i < 6; i++) {
					for (int j = 0; j < 3; j++) {
						c.board[i][j] = a.board[j + 3][2 - i + 3];
					} // 3,0 5,2
				}
				BasicPanel.b = c;
				System.out.println("\n");
				System.out.print("<회전 후>");
				BasicPanel.b.Print();
				// 승리검사
				BasicPanel.winnerCheck();
				Board R = BasicPanel.b;
				for (int i = 3; i < 6; i++) {
					for (int j = 0; j < 3; j++) {
						BasicPanel.StonePanel[i][j].removeAll();
					}
				}
				// ------
				for (int i = 3; i < 6; i++) {
					for (int j = 0; j < 3; j++) {
						if (R.board[i][j] == 0) {
							JLabel StoneFrame = new JLabel(
									new ImageIcon(Main.class.getResource("../images/StoneFrame.png")));
							BasicPanel.StonePanel[i][j].add(StoneFrame);

						} else if (R.board[i][j] == 1) {
							JLabel BlackStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/BlackStone.png")));
							BasicPanel.StonePanel[i][j].add(BlackStone);

						} else if (R.board[i][j] == 2) {
							JLabel WhiteStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/WhiteStone.png")));
							BasicPanel.StonePanel[i][j].add(WhiteStone);

						}
					}
				}
				// ------
			}
			TurnSet();
			RotationButtonOff();
			BasicPanel.flag = true;
		}

		if (Rnum == 5) {
			// 5번 rotate
			if (BasicPanel.flag == false) {

				// --------오른쪽회전
				Board a = BasicPanel.b;
				Board c = new Board();
				for (int i = 0; i < 6; i++) {
					for (int j = 0; j < 6; j++) {
						c.board[i][j] = a.board[i][j];
					}
				}
				for (int i = 3; i < 6; i++) {
					for (int j = 0; j < 3; j++) {
						c.board[i][j] = a.board[2 - j + 3][i - 3];
					} // 3,0 5,2
				}
				BasicPanel.b = c;
				System.out.println("\n");
				System.out.print("<회전 후>");
				BasicPanel.b.Print();
				// 승리검사
				BasicPanel.winnerCheck();
				Board R = BasicPanel.b;
				for (int i = 3; i < 6; i++) {
					for (int j = 0; j < 3; j++) {
						BasicPanel.StonePanel[i][j].removeAll();
					}
				}
				// ------
				for (int i = 3; i < 6; i++) {
					for (int j = 0; j < 3; j++) {
						if (R.board[i][j] == 0) {
							JLabel StoneFrame = new JLabel(
									new ImageIcon(Main.class.getResource("../images/StoneFrame.png")));
							BasicPanel.StonePanel[i][j].add(StoneFrame);

						} else if (R.board[i][j] == 1) {
							JLabel BlackStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/BlackStone.png")));
							BasicPanel.StonePanel[i][j].add(BlackStone);

						} else if (R.board[i][j] == 2) {
							JLabel WhiteStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/WhiteStone.png")));
							BasicPanel.StonePanel[i][j].add(WhiteStone);

						}
					}
				}
				// ------
			}

			TurnSet();
			RotationButtonOff();
			BasicPanel.flag = true;
		}

		if (Rnum == 6) {
			// 6번 rotate
			if (BasicPanel.flag == false) {
				// --------오른쪽회전
				Board a = BasicPanel.b;
				Board c = new Board();
				for (int i = 0; i < 6; i++) {
					for (int j = 0; j < 6; j++) {
						c.board[i][j] = a.board[i][j];
					}
				}
				for (int i = 3; i < 6; i++) {
					for (int j = 3; j < 6; j++) {
						c.board[i][j] = a.board[8 - j][i];
					} // 3,3 5,5
				}
				BasicPanel.b = c;
				System.out.println("\n");
				System.out.print("<회전 후>");
				BasicPanel.b.Print();
				// 승리검사
				BasicPanel.winnerCheck();
				Board R = BasicPanel.b;
				for (int i = 3; i < 6; i++) {
					for (int j = 3; j < 6; j++) {
						BasicPanel.StonePanel[i][j].removeAll();
					}
				}
				// ------
				for (int i = 3; i < 6; i++) {
					for (int j = 3; j < 6; j++) {
						if (R.board[i][j] == 0) {
							JLabel StoneFrame = new JLabel(
									new ImageIcon(Main.class.getResource("../images/StoneFrame.png")));
							BasicPanel.StonePanel[i][j].add(StoneFrame);

						} else if (R.board[i][j] == 1) {
							JLabel BlackStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/BlackStone.png")));
							BasicPanel.StonePanel[i][j].add(BlackStone);

						} else if (R.board[i][j] == 2) {
							JLabel WhiteStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/WhiteStone.png")));
							BasicPanel.StonePanel[i][j].add(WhiteStone);

						}
					}
				}
				// ------
			}

			TurnSet();
			RotationButtonOff();
			BasicPanel.flag = true;
		}

		if (Rnum == 7) {
			// 7번 rotate
			if (BasicPanel.flag == false) {
				// --------왼쪽회전
				Board a = BasicPanel.b;
				Board c = new Board();
				for (int i = 0; i < 6; i++) {
					for (int j = 0; j < 6; j++) {
						c.board[i][j] = a.board[i][j];
					}
				}
				for (int i = 3; i < 6; i++) {
					for (int j = 3; j < 6; j++) {
						c.board[i][j] = a.board[j][8 - i];
					} // 3,3 5,5
				}
				BasicPanel.b = c;
				System.out.println("\n");
				System.out.print("<회전 후>");
				BasicPanel.b.Print();
				// 승리검사
				BasicPanel.winnerCheck();
				Board R = BasicPanel.b;

				for (int i = 3; i < 6; i++) {
					for (int j = 3; j < 6; j++) {
						BasicPanel.StonePanel[i][j].removeAll();
					}
				}
				// ------
				for (int i = 3; i < 6; i++) {
					for (int j = 3; j < 6; j++) {
						if (R.board[i][j] == 0) {
							JLabel StoneFrame = new JLabel(
									new ImageIcon(Main.class.getResource("../images/StoneFrame.png")));
							BasicPanel.StonePanel[i][j].add(StoneFrame);

						} else if (R.board[i][j] == 1) {
							JLabel BlackStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/BlackStone.png")));
							BasicPanel.StonePanel[i][j].add(BlackStone);

						} else if (R.board[i][j] == 2) {
							JLabel WhiteStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/WhiteStone.png")));
							BasicPanel.StonePanel[i][j].add(WhiteStone);

						}
					}
				}
				// ------
			}

			TurnSet();
			RotationButtonOff();
			BasicPanel.flag = true;
		}

		if (BasicPanel.AiFlag == true && BasicPanel.Aiturn == true) {
			System.out.println(BasicPanel.Aiturn);
			System.out.println("ai진입");
			GameTree currentTree = new GameTree(BasicPanel.b);
			AI computer = new AI(depth);
			computer.intelligentMove(depth, currentTree, false);
			String[] array = computer.getBoard().getLastMove().split(" ");

			if (BasicPanel.b.isValidMove(Integer.parseInt(array[0]), Integer.parseInt(array[1]))) {
				BasicPanel.b.makeMove(2, Integer.parseInt(array[0]), Integer.parseInt(array[1]));
				BasicPanel.winnerCheck();
				if (BasicPanel.b.determineWinner() == 0)
					BasicPanel.b.rotate(array[2]);
				BasicPanel.winnerCheck();
			}

			for (int i = 0; i < 6; i++) {
				for (int j = 0; j < 6; j++) {
					BasicPanel.StonePanel[i][j].removeAll();
				}
			}

			for (int i = 0; i < 6; i++) {
				for (int j = 0; j < 6; j++) {
					if (BasicPanel.b.board[i][j] == 0) {
						JLabel StoneFrame = new JLabel(
								new ImageIcon(Main.class.getResource("../images/StoneFrame.png")));
						BasicPanel.StonePanel[i][j].add(StoneFrame);

					} else if (BasicPanel.b.board[i][j] == 1) {
						JLabel BlackStone = new JLabel(
								new ImageIcon(Main.class.getResource("../images/BlackStone.png")));
						BasicPanel.StonePanel[i][j].add(BlackStone);

					} else if (BasicPanel.b.board[i][j] == 2) {
						JLabel WhiteStone = new JLabel(
								new ImageIcon(Main.class.getResource("../images/WhiteStone.png")));
						BasicPanel.StonePanel[i][j].add(WhiteStone);

					}
				}
			}
			BasicPanel.Aiturn = false;
			BasicPanel.playerTurn = false;
			TurnSet();
			RotationButtonOff();
			// ai턴 끝나고 바뀐 배열을 새로운 이미지로 초기화가 필요
		}
	}

	public class CountdownTimer extends JLabel {

		public double seconds;

		public CountdownTimer() {

			setSize(140, 40);

			// 타이머설정
			Timer timer = new Timer(50, new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					if (BasicPanel.winner == 0)
						seconds = seconds - 0.051;
					setFont(getFont().deriveFont(20.0f));
					setText("      " + (int) seconds + "초");

					if (seconds <= 1 && BasicPanel.flag == true && BasicPanel.AiFlag == false) {// 돌 안놓았을때
						seconds = 31;
						BasicPanel.flag = true;
						timeLimit = false;
						cdtblack.setVisible(false);
						cdtwhite.setVisible(false);
						RotationButtonOff();

					} else if (seconds <= 1 && BasicPanel.flag == false && BasicPanel.AiFlag == false) { // 돌은 놓았지만 제
																											// 시간에 회전
																											// 못했을경우
						seconds = 31;
						BasicPanel.flag = true;
						timeLimit = false;
						TurnSet();
						RotationButtonOff();
						BasicPanel.flag = true;
						timeLimit = true;
					}
				}
			});
			timer.start();
		}
	}

	public class ResultTimer extends JLabel {

		public double second;
		public int min = 0;

		public ResultTimer() {

			setSize(140, 40);

			// 타이머설정
			Timer timer = new Timer(50, new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					if (BasicPanel.winner == 0)
						second = second + 0.051;

					setFont(new Font("", Font.BOLD, 27));
					setText("게임시간 " + min + "분 " + (int) second + "초");

					if (second >= 60) {
						second = 0;
						min++;

					}
				}
			});
			timer.start();
		}
	}
}
