package pentagoApplication;

import java.util.ArrayList;

public class GameTree {
	
	Board thisBoard;
	ArrayList<GameTree> children;
	
	public GameTree(Board board) {
		thisBoard = board;
	}
	
	//children 트리 갱신
	public void populateNodeChildren() {
		
		ArrayList<Board> boardChildren = thisBoard.getChildren(); // boardChildren = 현 보드의 가능한한 모든 다음 수를 저장한 returnList
		children = new ArrayList<GameTree>();
		for(int i = 0; i < boardChildren.size(); i++) //가능한한 모든 다음 수 (returnList) 검사
		{
			children.add(new GameTree(boardChildren.get(i)));
		}
	}
	
	public int childNumber()
	{
		return children.size();
	}
	
	/////////////
	////접근자////
	////////////
	
	public ArrayList<GameTree> getChildTrees()
	{
		return children; // get child tree => array list 반환
		
	}
	
	public Board getBoard()
	{
		return thisBoard;
	}
}
