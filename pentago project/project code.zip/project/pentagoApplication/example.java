package pentagoApplication;

import java.awt.*;
import javax.swing.*;

public class example extends JFrame {
	
	//-----------------참고용 파일
	
	public Container setContainer() {
		return setContainer();
	}
	
	public example() {
		setTitle("Pentago");
		setVisible(true);
		setSize(1280, 720);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container container = getContentPane();
		container.setLayout(null);
		container.setBackground(Color.WHITE);

		
		
		
//         JButton[] Test = new JButton[9];
//         for (int i = 0; i < Test.length; i++) {
//            String a = String.valueOf(i);
//            Test[i] = new JButton();
//            Test[i].setText(a);
//         }

		JPanel BBasic = new JPanel();
		BBasic.setSize(700, 700);
		BBasic.setLocation(100, 100);
		BBasic.setLayout(new GridLayout(2, 2, 10, 10));
		container.add(BBasic);

		JPanel[] Fourth = new JPanel[4];
		for (int i = 0; i < Fourth.length; i++) {
			ImageIcon image = new ImageIcon("D:\\Project\\PartFrame.jpg");
			Fourth[i] = new JPanel() {
				@Override
				public void paintComponent(Graphics g) {
					super.paintComponent(g);
					g.drawImage(image.getImage(), 0, 0, getWidth(), getHeight(), this);

				}
			};
			Fourth[i].setSize(300, 300);
			BBasic.add(Fourth[i]);
			BBasic.setComponentZOrder(Fourth[i], 0);
			Fourth[i].setLayout(new GridLayout(3, 3));
		}

		JLabel[][] Dol = new JLabel[6][6];
		int cnt = 0;

		///
		for (int i = 0; i < Dol.length; i++) {
			for (int j = 0; j < Dol.length; j++) {
				Dol[i][j] = new JLabel(new ImageIcon("D:\\Project\\BlackDol.jpg"));
				Dol[i][j].setSize(100, 100);
				if (i < 3 && j < 3) {
					Fourth[0].add(Dol[i][j]);
					Fourth[0].setComponentZOrder(Dol[i][j], 0);
				} else if (i < 3 && 3 <= j) {
					Fourth[1].add(Dol[i][j]);

					Fourth[1].setComponentZOrder(Dol[i][j], 0);
				} else if (3 <= i && j < 3) {
					Fourth[2].add(Dol[i][j]);
					Fourth[2].setComponentZOrder(Dol[i][j], 0);
				}
				if (3 <= i && 3 <= j) {
					Fourth[3].add(Dol[i][j]);
					Fourth[3].setComponentZOrder(Dol[i][j], 0);
				}
			}
		}

	}
}