
//ImageIcon exitButtonOn = new ImageIcon(Main.class.getResource("../images/ExitButtonOn.png"));
//ImageIcon exitButtonOff = new ImageIcon(Main.class.getResource("../images/ExitButtonOff.png"));
package pentagoApplication;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class whitewin extends JFrame {

	ImageIcon restartbuttonOn = new ImageIcon(Main.class.getResource("../images/RestartButtonOn.png"));
	ImageIcon restartbuttonOff = new ImageIcon(Main.class.getResource("../images/RestartButtonOff.png"));
	ImageIcon MainButtonOn = new ImageIcon(Main.class.getResource("../images/MainButtonOn.png"));
	ImageIcon MainButtonOff = new ImageIcon(Main.class.getResource("../images/MainButtonOff.png"));
	JFrame frame = new JFrame();
	private JButton restart = new JButton(restartbuttonOff);
	private JButton returnmain = new JButton(MainButtonOff);
	JPanel winner = new JPanel();
	private JLabel win = new JLabel();

	public whitewin() {

		frame.setLayout(new FlowLayout());
		frame.setTitle("승리패널");
		frame.setSize(1280, 800);
		frame.setLocationRelativeTo(null);

		winner.setLayout(null);
	    winner.setPreferredSize(new Dimension(600, 450));
		winner.setBackground(Color.white);
		frame.add(winner);
		
		win.setBounds(190, 100, 250, 20);
		win.setText("백돌이 승리하였습니다!");
		win.setFont(win.getFont().deriveFont(20.0f));
		winner.add(win);

		restart.setBounds(40, 300, 250, 102);
		restart.setBorderPainted(false);
		restart.setContentAreaFilled(false);
		restart.setFocusPainted(false);
		restart.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				restart.setIcon(restartbuttonOn);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				restart.setIcon(restartbuttonOff);
			}
		});
		winner.add(restart);

		returnmain.setBounds(330, 295, 250, 102);
		returnmain.setBorderPainted(false);
		returnmain.setContentAreaFilled(false);
		returnmain.setFocusPainted(false);
		returnmain.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				returnmain.setIcon(MainButtonOn);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				returnmain.setIcon(MainButtonOff);
			}
		});
		winner.add(returnmain);

		frame.setVisible(true);

	}

	public static void main(String args[]) {
		new whitewin();
	}

}
