package pentagoApplication;

import java.util.ArrayList;

public class Board {
	int[][] board;
	public String lastMove = " ";

	public Board() {
		board = new int[6][6];
	}

	public boolean isFull() {
		int check = 0;
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 6; j++) {
				if (board[i][j] == 0) {
					check++;
				}
			}
		}

		if (check == 0)
			return true;
		else
			return false;
	}

	public Board(int[][] moves) {
		board = new int[6][6];
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 6; j++)
				board[i][j] = moves[i][j];
		}
	}

	public void Input(int i, int j, int StoneValue) {
		board[i][j] = StoneValue;
	}

	public int getBoard(int i, int j) {
		return board[i][j];
	}

	public void removeAll() {
		this.board = new int[6][6];
	}

	public void Print() {
		for (int i = 0; i < 6; i++)
			for (int j = 0; j < 6; j++) {
				if (j == 0)
					System.out.println();
				System.out.print(board[i][j] + " ");
			}
	}

	public int determineWinner() {
		for (int i = 0; i < 6; i++) {
			if ((board[i][0] == 1) && (board[i][1] == 1) && (board[i][2] == 1) && (board[i][3] == 1)
					&& (board[i][4] == 1))
				return 1;
			if ((board[i][0] == 2) && (board[i][1] == 2) && (board[i][2] == 2) && (board[i][3] == 2)
					&& (board[i][4] == 2)) {
				return 2;
			}
		}

		for (int i = 0; i < 6; i++) {
			if ((board[i][1] == 1) && (board[i][2] == 1) && (board[i][3] == 1) && (board[i][4] == 1)
					&& (board[i][5] == 1))
				return 1;
			if ((board[i][1] == 2) && (board[i][2] == 2) && (board[i][3] == 2) && (board[i][4] == 2)
					&& (board[i][5] == 2)) {
				return 2;
			}
		}

		for (int i = 0; i < 6; i++) {
			if ((board[0][i] == 1) && (board[1][i] == 1) && (board[2][i] == 1) && (board[3][i] == 1)
					&& (board[4][i] == 1))
				return 1;
			if ((board[0][i] == 2) && (board[1][i] == 2) && (board[2][i] == 2) && (board[3][i] == 2)
					&& (board[4][i] == 2)) {
				return 2;
			}
		}

		for (int i = 0; i < 6; i++) {
			if ((board[1][i] == 1) && (board[2][i] == 1) && (board[3][i] == 1) && (board[4][i] == 1)
					&& (board[5][i] == 1))
				return 1;
			if ((board[1][i] == 2) && (board[2][i] == 2) && (board[3][i] == 2) && (board[4][i] == 2)
					&& (board[5][i] == 2)) {
				return 2;
			}
		}

		if ((board[0][1] == 1) && (board[1][2] == 1) && (board[2][3] == 1) && (board[3][4] == 1) && (board[4][5] == 1))
			return 1;
		if ((board[0][1] == 2) && (board[1][2] == 2) && (board[2][3] == 2) && (board[3][4] == 2)
				&& (board[4][5] == 2)) {
			return 2;
		}

		if ((board[1][0] == 1) && (board[2][1] == 1) && (board[3][2] == 1) && (board[4][3] == 1) && (board[5][4] == 1))
			return 1;
		if ((board[1][0] == 2) && (board[2][1] == 2) && (board[3][2] == 2) && (board[4][3] == 2)
				&& (board[5][4] == 2)) {
			return 2;
		}

		if ((board[0][4] == 1) && (board[1][3] == 1) && (board[2][2] == 1) && (board[3][1] == 1) && (board[4][0] == 1))
			return 1;
		if ((board[0][4] == 2) && (board[1][3] == 2) && (board[2][2] == 2) && (board[3][1] == 2)
				&& (board[4][0] == 2)) {
			return 2;
		}

		if ((board[1][5] == 1) && (board[2][4] == 1) && (board[3][3] == 1) && (board[4][2] == 1) && (board[5][1] == 1))
			return 1;
		if ((board[1][5] == 2) && (board[2][4] == 2) && (board[3][3] == 2) && (board[4][2] == 2)
				&& (board[5][1] == 2)) {
			return 2;
		}

		if ((board[0][0] == 1) && (board[1][1] == 1) && (board[2][2] == 1) && (board[3][3] == 1) && (board[4][4] == 1))
			return 1;
		if ((board[0][0] == 2) && (board[1][1] == 2) && (board[2][2] == 2) && (board[3][3] == 2)
				&& (board[4][4] == 2)) {
			return 2;
		}

		if ((board[1][1] == 1) && (board[2][2] == 1) && (board[3][3] == 1) && (board[4][4] == 1) && (board[5][5] == 1))
			return 1;
		if ((board[1][1] == 2) && (board[2][2] == 2) && (board[3][3] == 2) && (board[4][4] == 2)
				&& (board[5][5] == 2)) {
			return 2;
		}

		if ((board[0][5] == 1) && (board[1][4] == 1) && (board[2][3] == 1) && (board[3][2] == 1) && (board[4][1] == 1))
			return 1;
		if ((board[0][5] == 2) && (board[1][4] == 2) && (board[2][3] == 2) && (board[3][2] == 2)
				&& (board[4][1] == 2)) {
			return 2;
		}

		if ((board[1][4] == 1) && (board[2][3] == 1) && (board[3][2] == 1) && (board[4][1] == 1) && (board[5][0] == 1))
			return 1;
		if ((board[1][4] == 2) && (board[2][3] == 2) && (board[3][2] == 2) && (board[4][1] == 2)
				&& (board[5][0] == 2)) {
			return 2;
		}

		return 0;
	}

	// AI 구현용
	public void setLastMove(String move) {
		lastMove = move;
	}

	public String getLastMove() {
		return lastMove;
	}

	public boolean isValidMove(int i, int j) {
		return (board[i - 1][j - 1] == 0);
	}

	public void makeMove(int player, int row, int col) {
		board[row - 1][col - 1] = player;
	}

	// 현 보드의 흑, 백 돌 상태의 점수
	public int getUtility() {
		int utility = 0;
		int streak = 0; // 보드 상태보고 가산점 정함 ex) 2개의 돌이 연속 = 1점, 3개 " " = 2점....

		// 수평 2개(더블) 카운트
		for (int i = 0; i < 6; i++) // i = 0행 -> 1행 -> 2행 -> ... -> 5행 <수평검사>
		{
			for (int j = 0; j < 5; j++) // j = 더블 카운트 j 0 1 2 3 4 - 5가 넘으면 인덱스아웃 오류
			{ // i
				if (board[i][j] == 2 && board[i][j + 1] == 2) // 0 [ (2, 2), 1, 0, 0, 0 ]
				{ // 1 [ 0, 0, 0, 0, 0, 0 ]
					utility += streak + 1; // ...
					streak++;
				} else
					streak = 0;
			}
		}

		// 수직 더블 카운트
		for (int i = 0; i < 6; i++) // 0열, 1열 , ... , 5열 <수직검사>
		{
			for (int j = 0; j < 5; j++) // 더블 카운트
			{
				if (board[j][i] == 2 && board[i][j + 1] == 2) {
					utility += streak + 1;
					streak++;
				} else
					streak = 0;
			}
		}

		// 대각선 \ 카운트
		for (int i = 0; i < 5; i++) {
			if (board[i][i] == 2 && board[i + 1][i + 1] == 2) {
				utility += streak + 1;
				streak++;
			} else
				streak = 0;
		}

		// 대각선 / 카운트
		for (int i = 0; i < 5; i++) {
			if (board[i][5 - i] == 2 && board[i + 1][4 - i] == 2) {
				utility += streak + 1;
				streak++;
			} else
				streak = 0;
		}

		return utility;
	}

	// makeMove함 : Input( i, j , 2);
	// player -> 백돌 , AI = 2, 흑돌 = 1;

	// 자식노드 설정, 가능한한 모든 다음수를 다룸(depth : 1)
	public ArrayList<Board> getChildren() {
		ArrayList<Board> returnList = new ArrayList<Board>();

		for (int i = 1; i < 7; i++)
			for (int j = 1; j < 7; j++) {
				if (isValidMove(i, j)) {
					Board tempBoard = new Board(board); // 자식노드용 보드
					tempBoard.makeMove(2, i, j);
					tempBoard.rotateA();
					tempBoard.setLastMove(i + " " + j + " " + "A");
					returnList.add(tempBoard);

				}

			}

		for (int i = 1; i < 7; i++)
			for (int j = 1; j < 7; j++) {
				if (isValidMove(i, j)) {
					Board tempBoard = new Board(board);
					tempBoard.makeMove(2, i, j);
					tempBoard.rotateB();
					tempBoard.setLastMove(i + " " + j + " " + "B");
					returnList.add(tempBoard);
				}
			}

		for (int i = 1; i < 7; i++)
			for (int j = 1; j < 7; j++) {
				if (isValidMove(i, j)) {
					Board tempBoard = new Board(board);
					tempBoard.makeMove(2, i, j);
					tempBoard.rotateC();
					tempBoard.setLastMove(i + " " + j + " " + "C");
					returnList.add(tempBoard);
				}
			}

		for (int i = 1; i < 7; i++)
			for (int j = 1; j < 7; j++) {
				if (isValidMove(i, j)) {
					Board tempBoard = new Board(board);
					tempBoard.makeMove(2, i, j);
					tempBoard.rotateD();
					tempBoard.setLastMove(i + " " + j + " " + "D");
					returnList.add(tempBoard);
				}
			}

		for (int i = 1; i < 7; i++)
			for (int j = 1; j < 7; j++) {
				if (isValidMove(i, j)) {
					Board tempBoard = new Board(board);
					tempBoard.makeMove(2, i, j);
					tempBoard.rotatea();
					tempBoard.setLastMove(i + " " + j + " " + "a");
					returnList.add(tempBoard);
				}
			}

		for (int i = 1; i < 7; i++)
			for (int j = 1; j < 7; j++) {
				if (isValidMove(i, j)) {
					Board tempBoard = new Board(board);
					tempBoard.makeMove(2, i, j);
					tempBoard.rotateb();
					tempBoard.setLastMove(i + " " + j + " " + "b");
					returnList.add(tempBoard);
				}
			}

		for (int i = 1; i < 7; i++)
			for (int j = 1; j < 7; j++) {
				if (isValidMove(i, j)) {
					Board tempBoard = new Board(board);
					tempBoard.makeMove(2, i, j);
					tempBoard.rotatec();
					tempBoard.setLastMove(i + " " + j + " " + "c");
					returnList.add(tempBoard);
				}
			}

		for (int i = 1; i < 7; i++)
			for (int j = 1; j < 7; j++) {
				if (isValidMove(i, j)) {
					Board tempBoard = new Board(board);
					tempBoard.makeMove(2, i, j);
					tempBoard.rotated();
					tempBoard.setLastMove(i + " " + j + " " + "d");
					returnList.add(tempBoard);
				}
			}

		return returnList; // 가능한한 모든 자식노드를 저장한 ArrayList<Board>
	}

	// 행렬 시계방향 회전
	static int[][] rotateClockwise(int[][] mat) {
		final int m = mat.length;
		final int n = mat[0].length;
		int[][] ret = new int[n][m];
		for (int r = 0; r < m; r++) {
			for (int c = 0; c < n; c++) {
				ret[c][m - 1 - r] = mat[r][c];
			}
		}
		return ret;
	}

	// 행렬 반시계 방향 회전
	static int[][] rotateCounterClockwise(int[][] mat) {
		return rotateClockwise(rotateClockwise(rotateClockwise(mat)));
	}

	public void rotate(String key) {
		// 반시계 방향 회전
		if (Character.isUpperCase(key.charAt(0))) {
			if (key.equals("A")) {
				rotateA();
			} else if (key.equals("B")) {
				rotateB();
			} else if (key.equals("C")) {
				rotateC();
			} else if (key.equals("D")) {
				rotateD();
			}
		} else // 시계 방향 회전
		{
			if (key.equals("a")) {
				rotatea();
			} else if (key.equals("b")) {
				rotateb();
			} else if (key.equals("c")) {
				rotatec();
			} else if (key.equals("d")) {
				rotated();
			}
		}
	}

	public void rotateA() {
		int[][] quadrant = new int[3][3];
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				quadrant[i][j] = board[i][j];
			}
		}
		quadrant = rotateCounterClockwise(quadrant);
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				board[i][j] = quadrant[i][j];
			}
		}
	}

	public void rotateB() {
		int[][] quadrant = new int[3][3];
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				quadrant[i][j] = board[i][j + 3];
			}
		}
		quadrant = rotateCounterClockwise(quadrant);
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				board[i][j + 3] = quadrant[i][j];
			}
		}
	}

	public void rotateC() {
		int[][] quadrant = new int[3][3];
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				quadrant[i][j] = board[i + 3][j];
			}
		}
		// rotate quadrant
		quadrant = rotateCounterClockwise(quadrant);
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				board[i + 3][j] = quadrant[i][j];
			}
		}
	}

	public void rotateD() {
		int[][] quadrant = new int[3][3];
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				quadrant[i][j] = board[i + 3][j + 3];
			}
		}
		quadrant = rotateCounterClockwise(quadrant);
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				board[i + 3][j + 3] = quadrant[i][j];
			}
		}
	}

	public void rotatea() {
		int[][] quadrant = new int[3][3];
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				quadrant[i][j] = board[i][j];
			}
		}
		quadrant = rotateClockwise(quadrant);
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				board[i][j] = quadrant[i][j];
			}
		}
	}

	public void rotateb() {
		int[][] quadrant = new int[3][3];
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				quadrant[i][j] = board[i][j + 3];
			}
		}
		quadrant = rotateClockwise(quadrant);
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				board[i][j + 3] = quadrant[i][j];
			}
		}
	}

	public void rotatec() {
		int[][] quadrant = new int[3][3];
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				quadrant[i][j] = board[i + 3][j];
			}
		}
		quadrant = rotateClockwise(quadrant);
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				board[i + 3][j] = quadrant[i][j];
			}
		}
	}

	public void rotated() {
		int[][] quadrant = new int[3][3];
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				quadrant[i][j] = board[i + 3][j + 3];
			}
		}
		quadrant = rotateClockwise(quadrant);
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				board[i + 3][j + 3] = quadrant[i][j];
			}
		}
	}
}
