package pentagoApplication;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class BasicPanel extends JPanel {

	static boolean AiFlag = true;
	static boolean Aiturn = false;
	static boolean playerTurn = true;
	static boolean flag = true;
	static int winner = 0;
	static boolean FinalFlag = true;

	static Board b = new Board();
	static JPanel[][] StonePanel = new JPanel[6][6];

	public static void PlayTurnChange() {
		if (playerTurn)
			playerTurn = false;
		else
			playerTurn = true;
	}

	public BasicPanel() {
		// BasicPanel에 6X6 StonePanel패널을 넣는다.

		// StonePanel패널 선언해줌
		for (int i = 0; i < StonePanel.length; i++) {
			for (int j = 0; j < StonePanel.length; j++) {
				StonePanel[i][j] = new JPanel();
				StonePanel[i][j].setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
				String Si = Integer.toString(i);
				String Sj = Integer.toString(j);
				StonePanel[i][j].setName(Si);
				StonePanel[i][j].setToolTipText(Sj);
				StonePanel[i][j].setVisible(true);
				StonePanel[i][j].setSize(100, 100);
				StonePanel[i][j].setBackground(Color.white);
				JLabel StoneFrame = new JLabel(new ImageIcon(Main.class.getResource("../images/StoneFrame.png")));
				StoneFrame.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
				StoneFrame.setSize(100, 100);
				StonePanel[i][j].setComponentZOrder(StoneFrame, 0);
				StonePanel[i][j].add(StoneFrame);
				StonePanel[i][j].addMouseListener(new MouseAdapter() {

					@Override
					public void mousePressed(MouseEvent e) {
						Music buttonEnteredMusic = new Music("buttonPressedMusic.mp3", false);
						buttonEnteredMusic.start();

//						Random rand = new Random();
//						JPanel pan = (JPanel) e.getSource();
//						pan.setBackground(new Color(rand.nextInt(254), rand.nextInt(254), rand.nextInt(254)));
						JPanel pan = (JPanel) e.getSource();
						int newI = Integer.parseInt(pan.getName());
						int newJ = Integer.parseInt(pan.getToolTipText());
						if (b.board[newI][newJ] == 0 && flag == true && AiFlag == false && FinalFlag == true) {
							pan.removeAll();
							if (playerTurn == true) {
								// true 면 백돌차례
								b.Input(newI, newJ, 2);
								System.out.println("\n");
								System.out.println("-----------");
								System.out.println(newI + "," + newJ + "에 두었습니다");
								System.out.println("백돌차례" + playerTurn);
								JLabel WhiteStone = new JLabel(
										new ImageIcon(Main.class.getResource("../images/WhiteStone.png")));
								WhiteStone.setSize(100, 100);
								pan.add(WhiteStone);

								if (!Pentago.timeLimit) {
									Pentago.timeLimit = true;
									System.out.println("white");
									playerTurn = false;
									flag = true;
									Pentago.TurnSet();
									Pentago.RotationButtonOff();
								} else {
									Pentago.RotationButtonOn();
									playerTurn = false;
									flag = false;
									b.Print();
								}
							} else {
								// false 면 흑돌차례
								b.Input(newI, newJ, 1);
								System.out.println("\n");
								System.out.println("-----------");
								System.out.println(newI + "," + newJ + "에 두었습니다");
								System.out.println("흑돌차례" + playerTurn);
								JLabel BlackStone = new JLabel(
										new ImageIcon(Main.class.getResource("../images/BlackStone.png")));
								BlackStone.setSize(100, 100);
								pan.add(BlackStone);
								if (!Pentago.timeLimit) {
									Pentago.timeLimit = true;
									System.out.println("black");
									playerTurn = true;
									flag = true;
									Pentago.TurnSet();
									Pentago.RotationButtonOff();

								} else {
									Pentago.RotationButtonOn();
									playerTurn = true;
									flag = false;
									b.Print();
								}

							}
						}

						if (b.board[newI][newJ] == 0 && flag == true && AiFlag == true && playerTurn == false
								&& FinalFlag == true) {
							pan.removeAll();
							// false 면 흑돌차례
							b.Input(newI, newJ, 1);

							System.out.println(newI + "," + newJ + "에 두었습니다");
							System.out.println("흑돌차례" + playerTurn);
							JLabel BlackStone = new JLabel(
									new ImageIcon(Main.class.getResource("../images/BlackStone.png")));
							BlackStone.setSize(100, 100);
							pan.add(BlackStone);
							Pentago.RotationButtonOn();
							playerTurn = true;
							flag = false;
							Aiturn = true;
							b.Print();
						}

						// 승리 검사
						winnerCheck();
					}

					// 마우스가 바둑판 CELL 에 올라가면 투명한 흑돌, 백돌이미지로 마꿈
					@Override
					public void mouseEntered(MouseEvent e) {
						JPanel pan = (JPanel) e.getSource();
						int newI = Integer.parseInt(pan.getName());
						int newJ = Integer.parseInt(pan.getToolTipText());
						if (b.board[newI][newJ] == 0 && playerTurn == true && flag == true && AiFlag == false
								&& FinalFlag == true) {
							pan.removeAll();
							JLabel WhiteStoneOn = new JLabel(
									new ImageIcon(Main.class.getResource("../images/WhiteStoneOn.png")));
							WhiteStoneOn.setSize(100, 100);
							WhiteStoneOn.setVisible(true);
							pan.add(WhiteStoneOn);
						} else if (b.board[newI][newJ] == 0 && playerTurn == false && flag == true
								&& FinalFlag == true) {
							pan.removeAll();
							JLabel BlackStoneOn = new JLabel(
									new ImageIcon(Main.class.getResource("../images/BlackStoneOn.png")));
							BlackStoneOn.setSize(100, 100);
							BlackStoneOn.setVisible(true);
							pan.add(BlackStoneOn);
						}
					}

					@Override
					public void mouseExited(MouseEvent e) {
						JPanel pan = (JPanel) e.getSource();
						int newI = Integer.parseInt(pan.getName());
						int newJ = Integer.parseInt(pan.getToolTipText());
						if (b.board[newI][newJ] == 0 && flag == true) {
							pan.removeAll();
							JLabel StoneFrame = new JLabel(
									new ImageIcon(Main.class.getResource("../images/StoneFrame.png")));
							StoneFrame.setSize(100, 100);
							StoneFrame.setVisible(true);
							pan.add(StoneFrame);
						}

					}

				});
				add(StonePanel[i][j]);
			}
		}
	}

	static void winnerCheck() {
		winner = b.determineWinner();

		if (winner == 1) {
			Pentago.ResultPanel.setLocation(400, 270);
			Pentago.ResultPanel.setVisible(true);
			FinalFlag = false;
			System.out.println("흑돌 승리");
			Pentago.ResultLabel.setIcon(new ImageIcon(Main.class.getResource("../images/BlackStoneTurn.png")));
			Pentago.ResultLabel.setSize(400, 100);
			Pentago.ResultLabel.setLocation(50, 50);
			Pentago.ResultLabel.setVisible(true);
			Pentago.ResultLabel.setFont(new Font("", Font.BOLD, 27));
			Pentago.ResultLabel.setText("흑돌이 승리하였습니다!");
			Pentago.RotationButtonOff();
			Pentago.ResultPanel.addMouseMotionListener(new MouseMotionListener() {

				@Override
				public void mouseMoved(MouseEvent e) {
				}

				@Override
				public void mouseDragged(MouseEvent e) {
					Pentago.ResultPanel.setLocation(e.getX(), e.getY());

				}
			});
			Pentago.ResultPanel.add(Pentago.ResultLabel);
		} else if (winner == 2) {
			Pentago.ResultPanel.setLocation(400, 270);
			Pentago.ResultPanel.setVisible(true);
			FinalFlag = false;
			System.out.println("백돌 승리");
			Pentago.ResultLabel.setIcon(new ImageIcon(Main.class.getResource("../images/WhiteStoneTurn.png")));
			Pentago.ResultLabel.setSize(400, 100);
			Pentago.ResultLabel.setLocation(50, 50);
			Pentago.ResultLabel.setVisible(true);
			Pentago.ResultLabel.setFont(new Font("", Font.BOLD, 27));
			Pentago.ResultLabel.setText("백돌이 승리하였습니다!");
			Pentago.RotationButtonOff();
			Pentago.ResultPanel.addMouseMotionListener(new MouseMotionListener() {

				@Override
				public void mouseMoved(MouseEvent e) {
				}

				@Override
				public void mouseDragged(MouseEvent e) {
					Pentago.ResultPanel.setLocation(e.getXOnScreen(), e.getYOnScreen());

				}
			});
			Pentago.ResultPanel.add(Pentago.ResultLabel);
		} else if (b.isFull()) {
			Pentago.ResultPanel.setLocation(400, 270);
			Pentago.ResultPanel.setVisible(true);
			FinalFlag = false;
			System.out.println("무승부");
			Pentago.ResultLabel.setIcon(new ImageIcon(Main.class.getResource("../images/WhiteStoneTurn.png")));
			Pentago.ResultLabel.setSize(400, 100);
			Pentago.ResultLabel.setLocation(50, 50);
			Pentago.ResultLabel.setVisible(true);
			Pentago.ResultLabel.setFont(new Font("", Font.BOLD, 27));
			Pentago.ResultLabel.setText("무승부 입니다!");
			Pentago.RotationButtonOff();
			Pentago.ResultPanel.addMouseMotionListener(new MouseMotionListener() {

				@Override
				public void mouseMoved(MouseEvent e) {
				}

				@Override
				public void mouseDragged(MouseEvent e) {
					Pentago.ResultPanel.setLocation(e.getXOnScreen(), e.getYOnScreen());

				}
			});
			Pentago.ResultPanel.add(Pentago.ResultLabel);
		}

	}
}