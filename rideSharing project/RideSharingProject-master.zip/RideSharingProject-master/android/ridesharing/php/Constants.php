<?php
	//declaration const value;
	define('DB_NAME','prawnguns');
	define('DB_USER','prawnguns');
	define('DB_PASSWORD','tjdwls!1214');
	define('DB_HOST','localhost');
?>